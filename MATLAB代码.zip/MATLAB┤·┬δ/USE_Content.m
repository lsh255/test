classdef USE_Content<handle
    %UNTITLED2 �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        USE_Content_use
         USE_Content_sumuncontent
         USE_Content_Weight
    end
    
    methods
        function obj = USE_Content(USE_Content_use,USE_Content_sumuncontent)
            obj.USE_Content_use = USE_Content_use;
            obj.USE_Content_sumuncontent =USE_Content_sumuncontent;
        end
        
        function set.USE_Content_use(obj,val)
            obj.USE_Content_use =val;
        end    
        
        function val=get.USE_Content_use(obj)
            val=obj.USE_Content_use;
        end
        
         function set.USE_Content_sumuncontent(obj,val)
            obj.USE_Content_sumuncontent =val;
        end    
        
        function val=get.USE_Content_sumuncontent(obj)
            val=obj.USE_Content_sumuncontent;
        end
        
        function set.USE_Content_Weight(obj,val)
            obj.USE_Content_Weight =val;
        end    
        
        function val=get.USE_Content_Weight(obj)
            val=obj.USE_Content_Weight;
        end
    end
    
end

