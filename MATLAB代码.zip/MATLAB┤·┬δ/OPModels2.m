function USE = OPModels2( USE,USElist,num,num2 )
%UNTITLED15 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
        for t =1 :length(USE.USE_contentUseList1)
            c_use = USE.USE_contentUseList1(1,t).USE_Content_use;
            SimliarityUselist = SimliarityUselist_of_USE(c_use,USElist,num);
            SimList = SimliarityUselist(1,1:num2);
            for t1 =1:length(SimList)
                USE_list(1,t1)=SimList(1,t1).use;
               
            end
             
            ALLsimUSElist(t,:) = USE_list;
        end
        
        
       m=1;
        for k =1:length(ALLsimUSElist(:,1))%������
            for l = 1 :length(ALLsimUSElist(1,:))%������
                simuse_use = ALLsimUSElist(k,l);
                 newAllsimUselist (1,m) =simuse_use.GET_ID();
                newAllsimUselist (2,m) = (21-k)*(6-l);
                m=m+1;
            end
        end
        newAllsimUselist1=sort(newAllsimUselist,2,'descend');
        
        
        [set_iDlist ib,ic]=unique(newAllsimUselist1(1,:));
        if length(set_iDlist)<20
            USE.USE_contentUseList3 = set_iDlist(1,1:length(set_iDlist));
            
        end
        if length(set_iDlist)>=20
        USE.USE_contentUseList3 = set_iDlist(1,1:20);
        
        end
end

