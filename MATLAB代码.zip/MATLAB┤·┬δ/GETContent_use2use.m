function uncontent = GETContent_use2use( USE,CUSE )
%UNTITLED6 ����˫�������
%   �˴���ʾ��ϸ˵��
    UseFeature=USE.GET_selffeature();
    CUseFeature=CUSE.GET_selffeature();
    UseChose=USE.GET_chose();
    CUseChose=CUSE.GET_chose();
            UF2CUC_sumuncontent=0;
            for i= 1:length(UseFeature)
               if i ==2 && CUseChose(1,i)==0
                   lcont = 0;
               elseif i ==3 && CUseChose(1,i)==1
                   lcont = 0;
               elseif i ==4 && CUseChose(1,i)==3
                   lcont = 0;
               elseif i ==5 && CUseChose(1,i)==5
                   lcont = 0;
               elseif i ==6 && CUseChose(1,i)==5
                   lcont = 0; 
               else
                   lcont= abs(UseFeature(1,i)-CUseChose(1,i))*CUseChose(2,i);  
               end
               UF2CUC_sumuncontent =UF2CUC_sumuncontent+lcont;
            end
           
            CUF2UC_sumuncontent=0;
            for i= 1:length(CUseFeature)
               if i ==2 && UseChose(1,i)==0
                   lcont = 0;
               elseif i ==3 && UseChose(1,i)==1
                   lcont = 0;
               elseif i ==4 && UseChose(1,i)==3
                   lcont = 0;
               elseif i ==5 && UseChose(1,i)==5
                   lcont = 0;
               elseif i ==6 && UseChose(1,i)==5
                   lcont = 0; 
               else
                   lcont= abs(CUseFeature(1,i)-UseChose(1,i))*UseChose(2,i);  
               end
               CUF2UC_sumuncontent =CUF2UC_sumuncontent+lcont;
            end
            uncontent =UF2CUC_sumuncontent+CUF2UC_sumuncontent;
        
end

