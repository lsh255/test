classdef Simliarity_Use<handle
    %UNTITLED11 �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        use
        sim
    end
    
    methods
        function obj = Simliarity_Use(use,sim)
            obj.use = use;
            obj.sim = sim;
        end
        
        function set.use(obj,val)
            obj.use =val;
        end     
        function val=get.use(obj)
            val=obj.use;
        end
        
        function set.sim(obj,val)
            obj.sim =val;
        end     
        function val=get.sim(obj)
            val=obj.sim;
        end
    end
    
end

