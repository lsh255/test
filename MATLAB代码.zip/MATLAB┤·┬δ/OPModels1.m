function USE = OPModels1( USE,USElist,num,num2 )
%UNTITLED14 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    SimliarityUselist = SimliarityUselist_of_USE(USE,USElist,num);
    SimList = SimliarityUselist(1,1:num2);
    
    for x = 1:length(SimList)
        simUSE = SimList(1,x).use;
        simUSE = BaseModels(simUSE,USElist);
        simUSE_contentUseLis = simUSE.USE_contentUseList1;
        ALLsimUSEList(x,:) = simUSE_contentUseLis;
    end
    
        
        m=1;
        for k =1:length(ALLsimUSEList(:,1))%������
            for l = 1 :length(ALLsimUSEList(1,:))%������
                simuse_use = ALLsimUSEList(k,l);
                
                newAllsimUselist (1,m) =simuse_use.USE_Content_use.GET_ID();
                newAllsimUselist (2,m) = (6-k)*(21-l);
                m=m+1;
            end
        end
        newAllsimUselist1=sort(newAllsimUselist,2,'descend');
        
         [set_iDlist ib,ic]=unique(newAllsimUselist1(1,:));
    if length(set_iDlist)<20
            USE.USE_contentUseList2 = set_iDlist(1,1:length(set_iDlist));
        end
     if length(set_iDlist)>=20
        USE.USE_contentUseList2 = set_iDlist(1,1:20);
        end
end

