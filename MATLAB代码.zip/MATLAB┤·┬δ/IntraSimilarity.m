function IntraSimilarity = IntraSimilarity( USE,USElist,Pow )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    List =USE.GET_List();
    index =List(2:4,:);
    weights  = ones(3,20); 
    post = ones(3,20);
    for k = 1:3
        for k1 =1:20
        weights(k,k1)=weights(k,k1)*Pow(k);
        post(k,k1) = 21 - k1;
        end
    end
    index = reshape(index,1,60);
    weights =reshape(weights,1,60);
    post =reshape(post,1,60);
    sum =[index;weights;post];
    
    [set_index ib,ic]=unique(index);
    newsum =zeros(2,length(set_index));
    for j = 1:length(set_index)
       for i  =1:length(weights)
          if set_index(1,j) ==sum(1,i)
              newsum(1,j)= set_index(1,j);
              newsum(2,j) = newsum(2,j)+(sum(2,i)*sum(3,i));
          end
       end
    end
     D=sort(newsum,2,'descend');
     newlist = D(:,1:20);
     IDlist =[];
     sumdis = 0;
     for k = 1:length(newlist)
         use = USElist(1,newlist(1,k));
         IDlist(1,k) =use.GET_ID();
         for k1 = 1:length(newlist)
             use1 = USElist(1,newlist(1,k1));
             if k~=k1
                  use_feature = use.GET_selffeature();
                  use1_feature = use1.GET_selffeature();
                  use_chose = use.GET_chose();
                  use1_chose = use1.GET_chose();
                  use_chose1 =prod(use_chose);
                  use1_chose1 =prod(use1_chose);
                  use_obj = [use_feature,use_chose1];
                  use_obj1 =[use1_feature,use1_chose1];
                   x = [use_obj;use_obj1];
                   distance_cosine=1-pdist(x,'cosine');                  
                   sumdis =sumdis+distance_cosine;
             end
         end   
     end
     USE.USE_contentUseLastList =IDlist;
     %�û��б������������ 
     IntraSimilarity = 1/(sumdis/(2*length(newlist)));
     %disp(IntraSimilarity);
     %disp(IDlist(1,1:5));
     
     

end

