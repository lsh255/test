function InteDiversity = InteDiversity( T_list)
%UNTITLED6 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    newt_list = reshape(T_list,1,9); 
    sum =0;
    for use =1:length(newt_list)
        for use1 =1:length(newt_list)
            if use~=use1
                h(1,1:20)=newt_list(1,use).USE_contentUseLastList;
                h(1,21:40)=newt_list(1,use).USE_contentUseLastList;  
               [h1,b,c] =unique(h);
               sum=sum+length(h1)/length(h);
            end
        end
        
    end
    InteDiversity = sum/2/(length(newt_list)*(length(newt_list)-1));
end

