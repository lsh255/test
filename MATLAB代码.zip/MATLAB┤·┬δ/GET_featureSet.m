function features_Set = GET_featureSet( USElist,features )
%GET_featureSet ���������Դ����
%   
    index=[char('age'),char('adress'),char('state'),char('height'),char('eb'),char('money')];
    
    for i = 1:length(USElist)
       use = USElist(1,i);
       if use.GET_sex == 1
           m_list=features(char(use.GET_sex));
           ufeature = use.GET_selffeature();
           for j =index
               list = m_list(j);
               for k = ufeature
                  dic=list(char(k));
                  num =dic('num');
                  dic('num') = num+1;
                  ulist=dic('uselist');
                  ulist(dic('num')) =use;
                  dic('uselist') =ulist;
                  list(char(k)) = dic;
               end
               m_list(j)= list;
           end
           features(char(use.GET_sex))=m_list;
       end
       if use.GET_sex == 0
            m_list=features(char(use.GET_sex));
           ufeature = use.GET_selffeature();
           for j =index
               list = m_list(j);
               for k = ufeature
                  dic=list(char(k));
                  num =dic('num');
                  dic('num') = num+1;
                  ulist=dic('uselist');
                  ulist(dic('num')) =use;
                  dic('uselist') =ulist;
                  list(char(k)) = dic;
               end
               m_list(j)= list;
           end
           features(char(use.GET_sex))=m_list;   
       end
    end
    features_Set = features;
end

