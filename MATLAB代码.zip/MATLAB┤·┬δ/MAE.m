function MAE = MAE( USE,USElist,Pow )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    List =USE.GET_List();
    index =List(2:4,:);
    weights  = ones(3,20);
    post = ones(3,20);
    for k = 1:3
        for k1 =1:20
        weights(k,k1)=weights(k,k1)*Pow(k);
        post(k,k1) = 21 - k1;
        end
    end
    index = reshape(index,1,60);
    weights =reshape(weights,1,60);
    post =reshape(post,1,60);
    sum =[index;weights;post];
    
   [set_index ib,ic]=unique(index);
    newsum =zeros(2,length(set_index));
    for j = 1:length(set_index)
       for i  =1:length(weights)
          if set_index(1,j) ==sum(1,i)
              newsum(1,j)= set_index(1,j);
              newsum(2,j) = newsum(2,j)+(sum(2,i)*sum(3,i));
          end
       end
    end
     D=sort(newsum,2,'descend');
     newlist = D(:,1:20);
     
     sumuncontent = 0;
     for k =1:length(newlist)
         use = USElist(1,newlist(1,k));
         uncontent= GETContent_use_of_use(USE,use);
         sumuncontent = sumuncontent+uncontent;
     end
         
        MAE = sumuncontent/length(newlist);
end

