function USE= Set_USEUnContentList( USE, USElist )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    
    
    for use = 1:length(USElist)
        if USE.GET_sex() ~= USElist(1,use).GET_sex()  
            ouseFeatureList=USElist(1,use).GET_selffeature();
            useChoseList=USE.GET_chose();
           % disp(useChoseList)
           % disp(ouseFeatureList)
            %disp('****')
            sumuncontent=0;
            for i= 1:length(ouseFeatureList)
               if i ==2 && useChoseList(1,i)==0
                   lcont = 0;
               elseif i ==3 && useChoseList(1,i)==1
                   lcont = 0;
               elseif i ==4 && useChoseList(1,i)==3
                   lcont = 0;
               elseif i ==5 && useChoseList(1,i)==5
                   lcont = 0;
               elseif i ==6 && useChoseList(1,i)==5
                   lcont = 0; 
               else
                   lcont= abs(useChoseList(1,i)-ouseFeatureList(1,i))*useChoseList(2,i);  
                end
                %disp([i,use,lcont])
               sumuncontent =sumuncontent+lcont;
            end 
           % disp('****')
            %disp(sumuncontent)
            objArray(1,use) = USE_Content(USElist(1,use),sumuncontent);
        end
        if USE.GET_sex() == USElist(1,use).GET_sex()  
            objArray(1,use) = USE_Content(USElist(1,use),100);
           %disp(100)
        end
    end
    USE.USE_contentUseList=objArray;
end

