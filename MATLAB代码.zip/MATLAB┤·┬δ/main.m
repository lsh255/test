function main()
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    USElist = GET_USElist('C:\Users\Administrator\Desktop\01.xlsx','sheet1');
    for n = 1:9
        USE = USElist(1,n);

     %---------------------------------------------  
        USE = BaseModels(USE,USElist);

    %----------------------------------------------------  
        USE =OPModels1(USE,USElist,0.7,5);
        USE =OPModels2(USE,USElist,0.7,5);
        T_list(1,n) =USE;
    end 
    T_list = reshape(T_list,3,3);
    
    %Pow =[0.5,0.3,0.2];
    %�����û��Ƽ��б���������
    %IntraSimilarity= IntraSimilarity(USE,USElist,Pow);
    %MAE = MAE(USE,USElist,Pow);
    
    X = rand(3,3);  
    Y = rand(3,3);
    Z = rand(3,3);
    IntraSimilarityList =zeros(3,3);
    MAEList =zeros(3,3);
    for l =1:length(X)
        for l1 =1:length(X)
            X(l,l1) =X(l,l1)/(X(l,l1)+Y(l,l1)+Z(l,l1));
            Y(l,l1) =Y(l,l1)/(X(l,l1)+Y(l,l1)+Z(l,l1));
            Z(l,l1) =Z(l,l1)/(X(l,l1)+Y(l,l1)+Z(l,l1));
            Pow1 =[X(l,l1),Y(l,l1),Z(l,l1)];
            IntraSimilarityList(l,l1) = IntraSimilarity(T_list(l,l1),USElist,Pow1);
            MAEList (l,l1)= MAE(T_list(l,l1),USElist,Pow1);
            %disp('*******');
            %disp(Pow1); 
        end
    end
    %subplot(1,2,1);
    
    InteDiversity= InteDiversity(T_list);
    
    surf(X,Y,Z,IntraSimilarityList)
    
   
    
    USElistALL = GET_USElist('C:\Users\Administrator\Desktop\Data_All.xlsx','All');

    USElistAge = GET_USElist('C:\Users\Administrator\Desktop\Data_All.xlsx','age');
    USElistregion = GET_USElist('C:\Users\Administrator\Desktop\Data_All.xlsx','region');
    USElistmatrimony = GET_USElist('C:\Users\Administrator\Desktop\Data_All.xlsx','matrimony');
    USElistheight = GET_USElist('C:\Users\Administrator\Desktop\Data_All.xlsx','height');
    USElisteducationbackground = GET_USElist('C:\Users\Administrator\Desktop\Data_All.xlsx','educationbackground');
    USElistincome = GET_USElist('C:\Users\Administrator\Desktop\Data_All.xlsx','income');
    
      Pow =[0.5,0.3,0.2];
    
    use1 =USElistALL(1,1);
        use1 = BaseModels(USE,USElist);
        use1 =OPModels1(USE,USElist,0.7,5);
        use1 =OPModels2(USE,USElist,0.7,5); 
        
        IntraSimilarityTlist(1,1) = IntraSimilarity(use1,USElistALL,Pow);
        MAETlist(1,1) = MAE(use1,USElistALL,Pow);
        
    use2 =USElistAge(1,1);
        use2 = BaseModels(USE,USElist);
        use2 =OPModels1(USE,USElist,0.7,5);
        use2 =OPModels2(USE,USElist,0.7,5); 
        
        IntraSimilarityTlist(1,2) = IntraSimilarity(use2,USElistAge,Pow);
        MAETlist(1,2) = MAE(use2,USElistAge,Pow);
        
    use3 =USElistregion(1,1);
        use3 = BaseModels(USE,USElist);
        use3 =OPModels1(USE,USElist,0.7,5);
        use3 =OPModels2(USE,USElist,0.7,5); 
        
        IntraSimilarityTlist(1,3) = IntraSimilarity(use3,USElistregion,Pow);
        MAETlist(1,3) = MAE(use3,USElistregion,Pow);
        
    use4 = USElistmatrimony(1,1);
        use4 = BaseModels(USE,USElist);
        use4 =OPModels1(USE,USElist,0.7,5);
        use4 =OPModels2(USE,USElist,0.7,5); 
        
        IntraSimilarityTlist(1,4) = IntraSimilarity(use4,USElistmatrimony,Pow);
        MAETlist(1,4) = MAE(use4,USElistmatrimony,Pow);
        
    use5 =USElistheight(1,1);
        use5 = BaseModels(USE,USElist);
        use5 =OPModels1(USE,USElist,0.7,5);
        use5 =OPModels2(USE,USElist,0.7,5); 
        
        IntraSimilarityTlist(1,5) = IntraSimilarity(use5,USElistheight,Pow);
        MAETlist(1,5) = MAE(use5,USElistheight,Pow);
        
    use6 = USElisteducationbackground(1,1);
        use6 = BaseModels(USE,USElist);
        use6 =OPModels1(USE,USElist,0.7,5);
        use6 =OPModels2(USE,USElist,0.7,5); 
        
        IntraSimilarityTlist(1,6) = IntraSimilarity(use6,USElisteducationbackground,Pow);
        MAETlist(1,6) = MAE(use6,USElisteducationbackground,Pow);
        
    use7 =USElistincome(1,1);
        use7 = BaseModels(USE,USElist);
        use7 =OPModels1(USE,USElist,0.7,5);
        use7 =OPModels2(USE,USElist,0.7,5); 
        
        IntraSimilarityTlist(1,7) = IntraSimilarity(use7,USElistincome,Pow);
        MAETlist(1,7) = MAE(use7,USElistincome,Pow);
end

