function  SimliarityUselist  = SimliarityUselist_of_USE( USE,USElist,limit_sim )
%UNTITLED15 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
   
    
    m=1;
    for i= 1:length(USElist)
       if USE.GET_sex() == USElist(1,i).GET_sex() 
            use_selfFeature = USE.GET_selffeature();
            other_use_selfFeature = USElist(1,i).GET_selffeature();
          use_chose = USE.GET_chose();
          other_use_chose = USElist(1,i).GET_chose();
          other_use_chose1 =prod(other_use_chose);
          use_chose1 =prod(use_chose);
          use1 = [use_selfFeature,use_chose1];
          other_use1 =[other_use_selfFeature,other_use_chose1];
           x = [use1;other_use1];
           distance_cosine=1-pdist(x,'cosine');
           %limit_sim==0.5/distance_consineԽСԽ����
           if distance_cosine<=limit_sim   
               SimliarityUse =Simliarity_Use(USElist(1,i),distance_cosine);
               objArray(1,m)=SimliarityUse;
               %disp(distance_cosine)
           end 
           if distance_cosine>limit_sim 
               SimliarityUse =Simliarity_Use(USElist(1,i),1);
               objArray(1,m)=SimliarityUse;
           end
           m =m+1;
       end
    end
        SimliarityUselist = myQuickSortbyUSESim(objArray,1,length(objArray));
    


end

