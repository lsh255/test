function features = SET_featureslist()
%UNTITLED9 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    
    m_feature_age_map =containers.Map;
    m_feature_age_map('num')=0;
    m_feature_age_map('uselist')=[];
    m_feature_age = containers.Map;
    for i = 0:5
        m_feature_age(char(i)) = m_feature_age_map';
    end
    
    
    m_feature_adress_map =containers.Map;
    m_feature_adress_map('num')=0;
    m_feature_adress_map('uselist')=[];
    m_feature_adress = containers.Map;
    for i = 1:32
        m_feature_adress(char(i)) = m_feature_adress_map;
    end
    
    m_feature_state_map =containers.Map;
    m_feature_state_map('num')=0;
    m_feature_state_map('uselist')=[];
    m_feature_state = containers.Map;
    for i = 0:2
        m_feature_state(char(i)) = m_feature_state_map;
    end
    
     m_feature_height_map =containers.Map;
    m_feature_height_map('num')=0;
    m_feature_height_map('uselist')=[];
    m_feature_height = containers.Map;
    for i = 0:2 
        m_feature_height(char(i))= m_feature_height_map;
    end
    
    m_feature_eb_map =containers.Map;
    m_feature_eb_map('num')=0;
    m_feature_eb_map('uselist')=[];
    m_feature_eb = containers.Map;
    for i = 0:4
    	m_feature_eb(char(i)) = m_feature_eb_map;
    end
    
    m_feature_money_map =containers.Map;
    m_feature_money_map('num')=0;
    m_feature_money_map('uselist')=[];
    m_feature_money = containers.Map;
    for i = 0:4
          m_feature_money(char(i)) = m_feature_money_map;
    end
    
    m_list=containers.Map;
    m_list(char('age'))=m_feature_age;
    m_list(char('adress'))=m_feature_adress;
    m_list(char('state'))=m_feature_state;
    m_list(char('height'))=m_feature_height;
    m_list(char('eb'))=m_feature_eb;
    m_list(char('money'))=m_feature_money;
    
    
   
   
    
    w_feature_age_map =containers.Map;
    w_feature_age_map('num')=0;
    w_feature_age_map('uselist')=[];
    w_feature_age = containers.Map;
    for i = 0:5
         w_feature_age(char(i)) = w_feature_age_map;
    end
    
    w_feature_adress_map =containers.Map;
    w_feature_adress_map('num')=0;
    w_feature_adress_map('uselist')=[];
    w_feature_adress = containers.Map;
    for i = 1:32
        w_feature_adress(char(i)) = w_feature_adress_map;
    end
    
     w_feature_state_map =containers.Map;
    w_feature_state_map('num')=0;
    w_feature_state_map('uselist')=[];
    w_feature_state = containers.Map;
    for i = 0:2
         w_feature_state(char(i)) = w_feature_state_map;
    end
    
    w_feature_height_map =containers.Map;
    w_feature_height_map('num')=0;
    w_feature_height_map('uselist')=[];
    w_feature_height = containers.Map;
    for i = 0:2
        w_feature_height(char(i))= w_feature_height_map;
    end
    
     w_feature_eb_map =containers.Map;
    w_feature_eb_map('num')=0;
    w_feature_eb_map('uselist')=[];
    w_feature_eb = containers.Map;
    for i = 0:4
          w_feature_eb(char(i)) = w_feature_eb_map;
    end
    
    w_feature_money_map =containers.Map;
    w_feature_money_map('num')=0;
    w_feature_money_map('uselist')=[];
    w_feature_money = containers.Map;
    for i = 0:4
         w_feature_money(char(i)) = w_feature_money_map;
    end
    
    w_list=containers.Map;
    w_list(char('age'))=w_feature_age;
    w_list(char('adress'))=w_feature_adress;
    w_list(char('state'))=w_feature_state;
    w_list(char('height'))=w_feature_height;
    w_list(char('eb'))=w_feature_eb;
    w_list(char('money'))=w_feature_money;
    %�����������ݽṹ
    features = containers.Map;
    features('1')  = m_list;
    features('0')  = w_list;
    
end

